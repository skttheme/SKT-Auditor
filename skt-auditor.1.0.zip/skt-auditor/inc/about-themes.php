<?php
//about theme info
add_action( 'admin_menu', 'skt_auditor_abouttheme' );
function skt_auditor_abouttheme() {    	
	add_theme_page( esc_html__('About Theme', 'skt-auditor'), esc_html__('About Theme', 'skt-auditor'), 'edit_theme_options', 'skt_auditor_guide', 'skt_auditor_mostrar_guide');   
} 
//guidline for about theme
function skt_auditor_mostrar_guide() { 
	//custom function about theme customizer
	$return = add_query_arg( array()) ;
?>
<div class="wrapper-info">
	<div class="col-left">
   		   <div class="col-left-area">
			  <?php esc_html_e('Theme Information', 'skt-auditor'); ?>
		   </div>
          <p><?php esc_html_e('SKT Auditor is built for firms that need trust and clarity. It suits every financial consultant, examiner, assessor, reviewer, evaluator and inspector who wants a simple site. The layout is clean and loads fast. You can show services, reports, case studies and contact details in an easy way. The theme works well for financial analysts, tax advisors and compliance teams. It is easy to set up and supports major plugins. The design looks professional on phones and laptops. It helps users build a strong online presence and share their work with clients in a clear and confident style.','skt-auditor'); ?></p>
          <a href="<?php echo esc_url(SKT_AUDITOR_SKTTHEMES_PRO_THEME_URL); ?>"><img src="<?php echo esc_url(get_template_directory_uri()); ?>/images/free-vs-pro.png" alt="<?php esc_attr_e('Free Vs Pro', 'skt-auditor'); ?>" /></a>
	</div><!-- .col-left -->
	<div class="col-right">			
			<div class="centerbold">
				<hr />
				<a href="<?php echo esc_url(SKT_AUDITOR_SKTTHEMES_LIVE_DEMO); ?>" target="_blank"><?php esc_html_e('Live Demo', 'skt-auditor'); ?></a> | 
				<a href="<?php echo esc_url(SKT_AUDITOR_SKTTHEMES_PRO_THEME_URL); ?>"><?php esc_html_e('Buy Pro', 'skt-auditor'); ?></a> | 
				<a href="<?php echo esc_url(SKT_AUDITOR_SKTTHEMES_THEME_DOC); ?>" target="_blank"><?php esc_html_e('Documentation', 'skt-auditor'); ?></a>
                <div class="space5"></div>
				<hr />                
                <a href="<?php echo esc_url(SKT_AUDITOR_SKTTHEMES_THEMES); ?>" target="_blank"><img src="<?php echo esc_url(get_template_directory_uri()); ?>/images/sktskill.jpg" alt="<?php esc_attr_e('SKT Themes', 'skt-auditor'); ?>" /></a>
			</div>		
	</div><!-- .col-right -->
</div><!-- .wrapper-info -->
<?php } ?>